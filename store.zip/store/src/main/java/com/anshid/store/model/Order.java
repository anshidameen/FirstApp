package com.anshid.store.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="orders")
public class Order {
	@Id
	@GeneratedValue
	private int id;
	
	@Column
	private String Pname;
	@Column
	private String Cname;
	@Column
	private int price;
	@Column
	private String Status;
	@Column
	private String Date;
	public Order(int id, String pname, String cname, int price, String status, String date) {
		super();
		this.id = id;
		Pname = pname;
		Cname = cname;
		this.price = price;
		Status = status;
		Date = date;
	}
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return Pname;
	}
	public void setPname(String pname) {
		Pname = pname;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	@Override
	public String toString() {
		return "Order [id=" + id + ", Pname=" + Pname + ", Cname=" + Cname + ", price=" + price + ", Status=" + Status
				+ ", Date=" + Date + "]";
	}
	
	
	
}
